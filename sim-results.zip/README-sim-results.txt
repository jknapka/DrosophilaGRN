The sim-results.zip file was too large to be checked into GitHub. It can
be found on Google Drive at the following URL:

https://drive.google.com/open?id=0B2GIlFWSlSITUDliQlpzdnRHd2M

